# Kitolov: namestitev na telefon

Kitolov je spletna aplikacija (PWA). Ko jo enkrat objaviš na brezplačnem gostovanju, si jo dodaš na začetni zaslon telefona in deluje kot navadna aplikacija.

## 1. Objava na GitHub Pages (brezplačno, približno 5 minut)

Najlažje je na računalniku.

1. Naredi brezplačen račun na github.com (če ga še nimaš).
2. Desno zgoraj klikni **+** → **New repository**.
   - Ime: `kitolov`
   - Izberi **Public**
   - Klikni **Create repository**.
3. Na strani novega repozitorija klikni povezavo **uploading an existing file**.
4. Povleci noter vse datoteke iz razpakirane mape (`index.html`, `sw.js`, `manifest.webmanifest`, `icon.svg`, `icon-180.png`, `icon-192.png`, `icon-512.png`). Klikni **Commit changes**.
5. Pojdi na **Settings** → **Pages**.
   - Pod *Branch* izberi `main` in mapo `/ (root)`, klikni **Save**.
6. Počakaj 1–2 minuti. Na isti strani se prikaže naslov, na primer `https://tvojeime.github.io/kitolov/`.

## 2. Dodaj na začetni zaslon

**iPhone (Safari):** odpri naslov → gumb Deli → **Dodaj na začetni zaslon**.

**Android (Chrome):** odpri naslov → meni ⋮ → **Namesti aplikacijo** ali **Dodaj na začetni zaslon**.

## 3. Posodobitve

Ko dobiš novo verzijo `index.html`, jo v repozitoriju naloži čez staro (**Add file** → **Upload files**). Telefon jo naloži ob naslednjem odprtju aplikacije.

## Kaj je kje

- **Radar**: coini v trendu na Solani, kiti (posli nad izbranim zneskom), opozorila in koliko tvojih pravil izpolnjujejo.
- **Dnevnik**: papirnati posli. Čez 1 h in 24 h aplikacija sama izmeri, kaj bi se zgodilo.
- **Pravila**: tvoji pogoji, varnostna kopija dnevnika in razlaga.

Dnevnik je shranjen samo v telefonu. Občasno ga kopiraj v zavihku Pravila.

Viri podatkov: GeckoTerminal, RugCheck, DexScreener (vsi brezplačni, brez ključev).

Kitolov ni finančni nasvet.
